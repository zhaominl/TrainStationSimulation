
public class TrainEvent
{
	int destination;
	int expectedArrival;
	public int getDestination()
	{
		return destination;
	}
	public void setDestination(int destination)
	{
		this.destination = destination;
	}
	public int getExpectedArrival()
	{
		return expectedArrival;
	}
	public void setExpectedArrival(int expectedArrival)
	{
		this.expectedArrival = expectedArrival;
	}
	
}
